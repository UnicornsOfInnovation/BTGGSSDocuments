# BTGGradeSubmissionSystem
BTG Grade Submission System is a Software Engineering Project of the Unicorns of Innovation for USC Pathways.
